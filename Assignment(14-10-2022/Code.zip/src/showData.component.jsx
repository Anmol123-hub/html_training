import "./css/myCss.css"
import { useEffect, useRef } from "react"
import { useState } from "react"
import axios from "axios"

var name = Array([])
var qty = Array([])
var price = Array([])
var total=0
var name1=""
let ShowData = ()=>{
    let elm=useRef()
    let[users,setUser] = useState([])
    let [ncart, updateCart] = useState({_id:'',hero:'', name : '', qty : 0, price : 0,instock:true});
    let refresh = ()=>{
        axios.get("http://localhost:2525/data").then(res => {
            setUser(res.data);
        })
    }
    let clickHandler = (evt)=>{
       
        updateCart({...ncart, qty : Number(evt.target.value)})
    }
    let editCart = (hid)=>{
       
        axios.get("http://localhost:2525/getData/"+hid).then(res => {
            updateCart(res.data);
            name1=res.data.hero
            name.push(name1)
            price.push(res.data.price)
            qty.push(ncart.qty)
            total+=ncart.qty*res.data.price
        })
    
        
    }
    useEffect(()=>{
        refresh()
    },[])
    return <div>
                {
                users.map((val,idx)=>{
                    return  <div key={val._id} className="box">

                                <p>TITLE : {val.hero}</p>
                                <p>NAME: {val.name}</p>
                                <p>PRICE: {val.price}</p>
                                <form action="#">
                                <label  id="qty">QUANTIY <br />
                                    <input ref={elm} type="number" onInput={(evt)=> clickHandler(evt)} id="qty" min="0" required/>
                                </label>
                                <input type="submit" onClick={()=> editCart(val._id)} className="btn btn-warning" value="ADD TO CART"/>
                                </form>
                               
                            </div>
                })
                }
                <div className="side_cart">
                
                <h1 style={{textAlign:"center"}}>Cart</h1>
                 
                 {
                    name.map((val,idx)=>{
                        return val!=""?<p key={idx}>Title: <br/> {val}</p>:<h2></h2> 
                    })
                }{
                    qty.map((val,idx)=>{
                        return val!=""?<p key={idx}>Qty: <br/> {val}</p>:<h2></h2>   
                    })
                }
                {
                    price.map((val,idx)=>{
                        return val!=""?<p key={idx}>Price: <br/> {val}</p>:<h2></h2>   
                    })
                }
              
                    <div style={{position:"absolute",bottom:0,left:0,right:0}}>
                        <p>Total:{total}</p>
                    </div>
                </div>
          
        </div>
   
}
export default ShowData
import ShowData from "./showData.component"

let App=()=>{
    return <div>
        
        <ShowData/>
    </div>
}
export default App
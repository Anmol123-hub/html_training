
let fs = require("fs")
let redux = require("redux")
let createStore = redux.legacy_createStore
const ADDHERO = "ADDHERO"
let addhero = ()=>{
    return{
        type:ADDHERO
    }
}
let initialState={
    numberOfHeros:""
}
let reducer = (state=initialState,action)=>{
    switch(action.type){
        case ADDHERO: 
        let new_data = new Array()
        const data = fs.readFileSync('../data/test.txt', 'ascii');
        new_data.push(data) 
        return {numberOfHeros:new_data}
        default: return state
    }
}
let store = createStore(reducer)
console.log("Initial value of store",store.getState())
let unsubscribe = store.subscribe(()=>console.log("Subscribed",store.getState()))

store.dispatch(addhero())


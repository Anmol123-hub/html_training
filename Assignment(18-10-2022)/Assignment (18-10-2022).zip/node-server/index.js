const fs = require("fs")
const process = require('process');


 let data = `Firstname ${process.argv[2]}\nLastname ${process.argv[3]}\nPower ${process.argv[4]}\n`
fs.appendFile("../data/test.txt",data, (err) => {
    if (err) {
      console.log(err);
    }
    else {
      // Get the file contents after the append operation
      console.log("\nFile Contents of file after append:",
        fs.readFileSync("../data/test.txt", "utf8"));
    }
  })
// fs.writeFileSync('../data/test', );

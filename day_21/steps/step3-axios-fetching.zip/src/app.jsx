import { Component } from "react";
import axios from "axios"
 
class App extends Component{
    state={
        users:[]
    }
    
    load_data1 = ()=>{
        axios.get("https://reqres.in/api/unknown")
        .then(res=>{
            this.setState({
                users:res.data.data
            })
            
        })
    }

    componentDidMount(){
        this.load_data1()
    }
    
    render(){
        return <div>
            <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Name</th>
                        <th scope="col">Year</th>
                        <th scope="col">Color</th>
                        <th scope="col">Pantone_value</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.users.map((val,idx)=>{   
                        return<tr key={val.id}>
                            <th scope="row">{idx+1}</th>
                            <td>{val.name}</td>
                            <td>{val.year}</td>
                            <td><input type="color" value={val.color}  disabled/></td>
                            <td>{val.pantone_value}</td>
                        </tr>
                        
                    })
                }
                </tbody>
                    
                    </table>
               </div>
    }
}
 
export default App;
 
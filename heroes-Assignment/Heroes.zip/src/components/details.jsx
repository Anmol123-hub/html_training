import data from "../data.json"
import "../myStyle.css"
import {useParams} from "react-router-dom"
let Details = ()=>{
    let params = useParams()
    return <div>
        {/* <h1>Anmol</h1> */}
       {
        data.heroes.map((val,idx)=>{
            if(params.id === val.id){
                return <div key={val.id} className="box">
                    <h1>Name : {val.name}</h1>
                    <h1>Power Stats</h1>
                    <h3>Power: {val.powerstats.power}</h3>
                    <h3>Inteliigence: {val.powerstats.intelligence}</h3>
                    <h3>Speed: {val.powerstats.speed}</h3>
                    <h3>Durability: {val.powerstats.durability}</h3>
                    <h1>Biography</h1>
                    <p>{val.biography["full-name"]}, {val.biography["place-of-birth"]},{val.biography["publisher"]}</p>
                    <h1>Appearance</h1>
                    <h4>gender: {val.appearance["gender"]}</h4>
                    <h4>Eye-color: {val.appearance["eye-color"]}</h4>
                    <h4>Race: {val.appearance["race"]}</h4>
                    </div>
            }
            
        })
       }
    </div>
}
export default Details
import Details from "./components/details"
import data from "./data.json"
import {BrowserRouter,Routes,Route,NavLink } from "react-router-dom"
import { useState } from "react"

let App=()=>{
   let [showLink,updateLink] = useState(true)
    return <div>
        <BrowserRouter>
    {
        <ul>
            {showLink &&<h1>List of Heroes</h1>}
            {showLink &&
                data.heroes.map((val,idx)=>{
                    return <li key={val.id}><NavLink onClick={()=>updateLink(false)} to={"/"+val.name+"/"+val.id}>{val.name}</NavLink></li>
                })
            }
            {!showLink&&
            <li ><NavLink to=""onClick={()=>updateLink(true)}>Go back to home</NavLink></li>}
        </ul>
    }
    <Routes>

    {data.heroes.map(route =>
     <Route key={route.id} path={route.name+"/:id"} element={<Details/>}  />
    )}

    </Routes>
    </BrowserRouter>
</div>
}
export default App
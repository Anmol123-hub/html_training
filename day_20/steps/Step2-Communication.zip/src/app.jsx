import { Component } from "react";
import FromChild from "./child";

class App extends Component{
    state={
        power:0,
        title:"Component",
        title1:"Anmol"
    }
    increasePower=()=>{
        this.setState({
            power:this.state.power+1
        })
    }
    decreasePower=()=>{
        this.setState({
            power:this.state.power-1
        })
    }
    changeFromChild=(ntitle,a)=>{
        this.setState({
            title:ntitle,
            title1:a
        })
    }
    
    render(){
        return <div>
            <h2>Power: {this.state.power}</h2>
            <h2>title : {this.state.title+" "+this.state.title1}</h2>
            <button onClick={this.increasePower}>Increase power</button>
            <button onClick={this.decreasePower}>Decrease power</button>
            <hr />
            <FromChild power={this.state.power} changeFromChild={this.changeFromChild} ></FromChild>
            {/* <FromChild power={this.state.power} changeFromChild1={this.changeFromChild1} /> */}
            
        </div>
    }
}
export default App
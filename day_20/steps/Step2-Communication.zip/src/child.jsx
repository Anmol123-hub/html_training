import { Component ,createRef} from "react";

class FromChild extends Component{
    elm = createRef();
    elm1 = createRef();
    
   
    render(){
        return <div>
            <h2> Child Power : {this.props.power}</h2>
            <input ref={this.elm} type="text" />
            <input ref={this.elm1} type="text" />
            <button onClick={()=>this.props.changeFromChild(this.elm.current.value,this.elm1.current.value)}>Change the title</button>
        </div>
    }
}
export default FromChild
import { Component } from "react";

class App extends Component{
    state={
        conditions:false
    }
    changeDefault=()=>{
        this.setState(function(){
            return{
            conditions:!this.state.conditions
            }
        
        },
        function(){
           console.log(this.state.conditions) 
        })
    }
    // changeDefault=()=>{
    //     this.setState=()=>{
    //         return conditions:!this.state.conditions
    //     }
    // }
    render(){
        return <div>
            <label htmlFor="">
                Accept the term and conditions
                <input type="checkbox" onChange={this.changeDefault}/>
            </label>
            {this.state.conditions && <fieldset>
                <legend>Terms & Conditions</legend>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab vel aut nesciunt corporis omnis animi fugiat labore cupiditate debitis facere iusto, voluptates voluptatem qui totam ad officia minus amet? Magnam?</p>
                </fieldset>}
        </div>
    }
}
export default App
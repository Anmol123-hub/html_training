
import { UseEffectComp } from "./components/useReducer";
 
export let App = ()=> {
  
    
 
    return <div>
                
                <UseEffectComp />
                
            </div>
}
 
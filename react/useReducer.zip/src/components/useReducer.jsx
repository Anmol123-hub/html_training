import { useRef } from "react";
import { useReducer } from "react";

let UseEffectComp = ()=> {

    let elm = useRef("null")
    let elm1 = useRef("null")
    let payload={
        firstname:elm.current.value,
        lastname:elm1.current.value
    }
    let reducerFun=(state,action)=>{
        switch(action.type){
            case "UPDATE_FIRSTNAME": return({...state,firstname:action.payload.firstname})
            case "UPDATE_LASTNAME": return({...state,firstname:action.payload.lastname})
            default: return state 
            }
    }
    let [state,dispatch] = useReducer(reducerFun,{firstname:"",lastname:""})
    return <div>
                <h2>use Reducer Hook Component</h2>
                <h3>Firstname: {state.firstname}</h3>
                <h3>Lastname: {state.lastname}</h3>
                Firstname: <input ref={elm} type="text"  />
                
                {/* <button onClick={()=>dispatch({type:"UPDATE_FIRSTNAME",payload:payload})}>Update</button> */}
                <br />
                <hr />
                Lastname: <input ref={elm1} type="text"  />
              
                <button onClick={()=>dispatch({type:"UPDATE_FIRSTNAME",type:"UPDATE_LASTNAME",payload:payload})}>Update</button>
            </div>
}
export { UseEffectComp };
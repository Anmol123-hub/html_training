import { Component } from "react";
import "./style/myStyle.css";
import client from "./client.module.css"

class App extends Component{

    render(){
        let myStyle = {backgroundColor:"red",color:"white",margin:"20px",padding:"20px"}
        return <div>
            <h2>App Component</h2>
            <h3>Destructring</h3>
            <article id="a" onMouseOver={this.gh} style={{...myStyle}}>Nulla placeat exercitationem, obcaecati illo quod adipisci animi a suscipit amet fuga delectus eius consequuntur! Dolorum placeat, distinctio sit, quo iure corrupti neque, amet natus molestias ut consequatur dolore eaque.</article>
            <h3>Destructring and changing the value</h3>
            <article style={{...myStyle,background:"orange"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque quia suscipit nostrum illum recusandae similique iure dolorum, officiis illo ut quidem iste vero magni ducimus velit sequi exercitationem earum sint?</article>
            <h3>Using external css file</h3>
            <article className="box">Ad amet provident eveniet in aut voluptatibus dolore, facilis aliquid deserunt obcaecati. Nihil, iste vel recusandae iure quaerat reprehenderit expedita sit at est dignissimos id, atque consequatur labore voluptate sint.</article>
            <h3>Using Client external css file</h3>
            <article className={client.box}>Quisquam, ad. Perferendis totam vero nulla, magni quia molestias reiciendis minus quibusdam libero dolores minima ut temporibus accusantium recusandae praesentium asperiores voluptate quo perspiciatis. Quae vel sapiente sunt consequatur recusandae!</article>
        </div>
    }
}
export default App
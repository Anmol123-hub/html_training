import { useEffect } from "react"
import { useState } from "react"
import axios from "axios"

let Users = ()=>{
    let[users,setUser] = useState([])
    let[support,setSupport] = useState([])

    useEffect(()=>{
        // axios.get("https://reqres.in/api/unknown").then(res=>{
        //     setUser(res.data.data)
        // })
        axios.get("http://localhost:2525/data").then(res=>{
            setSupport(res.data.support)
        })
    },[])

    return <div>
        <table className="table">
        <thead>
            <tr>
            <th scope="col">S.NO</th>
            <th scope="col">Name</th>
            <th scope="col">Year</th>
            <th scope="col">Color</th>
            <th scope="col">Panton Value</th>
            </tr>
        </thead>
        <tbody>
            {
                users.map((val,idx)=>{
                    return  <tr key={val.id}>
                                <th scope="row">{val.id}</th>
                                <td>{val.name}</td>
                                <td>{val.year}</td>
                                <td><input type="color" value={val.color} disabled/></td>
                                <td>{val.pantone_value}</td>
                            </tr>
                })
            }
        </tbody>
        </table>
        {/* <h1>{support.url}</h1> */}
        <a href={support.url}>Click Here</a>
        <h3>{support.text}</h3>
    </div>
}
export default Users
import Users from "./users.component"

let App=()=>{
    return <div>
        <h1>Users List</h1>
        <Users/>
    </div>
}
export default App
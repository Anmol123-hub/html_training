function Batman(){
    return <div>
        <h1>Batman</h1>
    </div>
}
export default Batman
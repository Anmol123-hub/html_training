function Aquaman(){
    return <div>
        <h1>Aquaman</h1>
    </div>
}
export default Aquaman
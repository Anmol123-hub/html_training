import { createRef,Component } from "react";
import PopUp from "./component/popup.component";

class App extends Component{
    elm = createRef()
    state={
        title:"hello",
        para:"",
        showPopup:false
    }
    change1 = ()=>{
        this.setState({
            para:this.elm.current.value
        })
    }
    change2 = ()=>{
        this.setState({
            para:this.state.para+" "+this.elm.current.value
        })
    }
    change3 = ()=>{
        var str = this.state.para
        var lastIndex = str.lastIndexOf(" ");
        str = str.substring(0, lastIndex);
        this.setState({
            para:str
        })
    }
    show=()=>{
        this.setState({
            showPopup:!this.state.showPopup
        })
    }
    render(){
        return <div>
            <h1>App Component</h1>
            <label htmlFor="enterFont">Enter your font here 
            <textarea ref={this.elm} id="enterFont" style={ {marginLeft:"10px",marginTop:"10px"} } rows="1" cols="30"/>

            <button onClick={this.change1}>Send</button>
            <button onClick={this.change2}>Concatenate</button>
            <button onClick={this.change3}>Remove</button>
            </label>
            {this.state.showPopup?<PopUp>
                <div>
                <h1>{this.state.title}</h1>
                <p>{this.state.para}</p>
                </div>
            </PopUp>:<button onClick={this.show}>Show</button>}
        </div>
    }
}
export default App
import ReactDOM from "react-dom";
import { Component } from "react";
 
class PopUp extends Component{
    render(){
        return ReactDOM.createPortal(this.props.children,document.getElementById("popup"))
    }
};
 
export default PopUp;
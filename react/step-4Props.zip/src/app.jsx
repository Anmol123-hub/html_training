import { Component } from "react";
import ChilComp from "./child.component";



class App extends Component{
    
    render(){
        return <div>
            <ChilComp title="Anmol" power={100} version={1}></ChilComp>
            <ChilComp title="Shaan"  version={2}></ChilComp>
            
            
        </div>
    }
}
export default App
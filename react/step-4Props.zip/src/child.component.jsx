import { Component } from "react";
import PropTypes from "prop-types"

class ChilComp extends Component{
    static propTypes={
        title:PropTypes.string.isRequired,
        power:PropTypes.number.isRequired,
        version:PropTypes.number.isRequired
    } 

    render(){
        return <div>
            <h2>{this.props.title}</h2>
            <h3>{this.props.power}</h3>
            <h4>{this.props.version}</h4>
        </div>
    }
    static defaultProps={
        title:"Default",
        power:0,
        version:0
    }
}
export default ChilComp
import { useEffect } from "react";

let UseEffectComp = (props)=> {

    useEffect(()=>{
        console.log("Component is mounted")
    },[])
    useEffect(()=>{
        console.log("Component is updated")
    },[props.state.version])

    useEffect(()=>{
        return()=>{
        console.log("Component is unmounted")
        }
    })



    return <div>
                <h2>UseEffect Hook</h2>
                <h3>Power is : { props.state.power }</h3>
                <h3>Version is : { props.state.version }</h3>
                <h3>Rating is : { props.state.rating }</h3>
            </div>
}
export { UseEffectComp };
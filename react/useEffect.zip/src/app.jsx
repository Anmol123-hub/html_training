import { useState } from "react"
import { UseEffectComp } from "./components/useEffectComp";
 
export let App = ()=> {
   /*  
   let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    let [rating, setRating] = useState(0); 
    */
    let [state, setState] = useState({ power: 0, version : 0, rating : 0});
    let increaseVersion=(evt)=>{
        state.version = evt.target.value
        setState({...state, version : state.version} )
    }
    
 
    return <div>
                <h1>Welcome to your life | Power is { state.power } | Version is : { state.version } | Rating : { state.rating }</h1>
                <input type="range" onChange={()=> setState({...state, power: state.power+1})} />
                <br />
                <input type="range" onChange={(evt)=> increaseVersion(evt)} />
                <br />
                <input type="range" onChange={()=> setState({...state, rating: state.rating+1} )} />
                {state.version<50?<UseEffectComp state={state}/>:<h2>Component removed</h2>}
                
            </div>
}
 
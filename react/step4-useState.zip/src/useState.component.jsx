import { useState } from "react"

let UsedStateComp = ()=>{
    let [hero,setHero] = useState({firstname:"",lastname:""})
    // let increasePower = ()=>setPower(power+1)
    let addHeroName=(evt)=>{
        setHero({
            ...hero,
        [evt.target.title] : evt.target.value
        })
    }
    return <div>
        <h1>User State Hooks</h1>
       <h1>Firstname: {hero.firstname}</h1>
       <h1>Lastname: {hero.lastname}</h1>
        <input type="text" title="firstname" onChange={(evt)=>addHeroName(evt)} />
        <br/>
        <input type="text" title="lastname" onChange={(evt)=>addHeroName(evt)} />
        {/* <button onClick={increasePower}>Increase</button> */}
    </div>
}
export default UsedStateComp
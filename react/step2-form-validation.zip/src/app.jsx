import { Component } from "react";
 
class App extends Component{
    state = {
        apptitle : "Forms in React",
        htitle : "",
        hname : "",
        hpower : 0,
        htitle_error : "",
        hname_error : "",
        hpower_error : "",
    }
    /* 
    titleChangeHandler = (evt)=>{
        this.setState({
            htitle : evt.target.value
        })
    }
    nameChangeHandler = (evt)=>{
        this.setState({
            hname : evt.target.value
        })
    }
    powerChangeHandler = (evt)=>{
        this.setState({
            hpower : evt.target.value
        })
    } 
    */

    changeHandler = (evt)=>{
        
        this.setState({
            [evt.target.id] : evt.target.value
        })
    }
    validateForm = ()=> {
        
        if( this.state.htitle === ""){
            this.setState({
                htitle_error : "Title is required"
            })
        }
        if(this.state.hname === ""){
            this.setState({
                hname_error : "Name is required"
            })
        }
        if(this.state.hpower === 0){
            
          
            //document.getElementById("err3").style="block"
            this.setState({
                hpower_error : "Power is required"
            })
        }else if(this.state.hpower < 5){
            
          
            //document.getElementById("err1").style="block"
            this.setState({
                hpower_error : "Power is less"
            })
        }else if(this.state.hpower >10) {
          
            //document.getElementById("err2").style="block"
            this.setState({
                hpower_error : "Power is more"
            })
        }else{
            this.setState({
                htitle_error : "",
        hname_error : "",
        hpower_error : ""
            })

        }
    }
    render(){
        return <div className="container">
                <h1>{ this.state.apptitle }</h1>
                    <div className="mb-3">
                        <label htmlFor="htitle" className="form-label">Title</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.htitle} id="htitle" type="text" className="form-control"/>
                        { this.state.htitle_error !== "" && <div className="form-text text-danger">{ this.state.htitle_error }</div> }
                    </div>
                    <div className="mb-3">
                        <label htmlFor="hname" className="form-label">Name</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.hname} id="hname" type="text" className="form-control"/>
                        { this.state.hname_error !== "" && <div className="form-text text-danger">Name is required</div> }
                    </div>
                    <div className="mb-3">
                        <label htmlFor="hpower" className="form-label">Power</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.hpower} id="hpower" type="range" className="form-control"/>
                        { (this.state.hpower>0&&this.state.hpower < 5) && <div className="form-text text-danger" id="err1">{this.state.hpower_error}</div> }
                        { this.state.hpower > 10 && <div className="form-text text-danger" id="err2">{this.state.hpower_error}</div> }
                        { this.state.hpower === 0 && <div className="form-text text-danger" id="err3">{this.state.hpower_error}</div> }
                    </div>
                    <button type="submit" onClick={ this.validateForm } className="btn btn-primary">Submit</button>
                    <ul>
                        <li>Title : { this.state.htitle }</li>
                        <li>Name : { this.state.hname }</li>
                        <li>Power : { this.state.hpower }</li>
                    </ul>
               </div>
    }
}
 
export default App;
 
 
// http://p.ip.fi/XRt_
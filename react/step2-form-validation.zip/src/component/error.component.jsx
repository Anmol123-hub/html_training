import { Component } from "react";
 
class ErrprBoundary extends Component{
    state = {
        message : "",
        hasError : false
    }
    static getDerivedStateFromError(error){
        return {
            message : error.message,
            hasError : true
        }
    }
   /*  
   componentDidCatch(){
 
    } 
    */
    render(){
       if(this.state.hasError){
        return <h3>Hero is not ready to fight : {this.state.message}</h3>
       }else{
        return this.props.children;
       }
    }
}
export default ErrprBoundary;
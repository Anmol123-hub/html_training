import { Component } from "react";
import { Hero1 } from "./hero";


class App extends Component{
    heroList=["Batman","Superman","Spiderman"]
    render(){
        return <div>
            <Hero1 list={this.heroList} version={1} title="Avengers"></Hero1>
            <Hero1 list={this.heroList} version={2} title="AntMan"></Hero1>
            <Hero1 list={this.heroList} version={3} title="Anmol"></Hero1>
            
        </div>
    }
}
export default App
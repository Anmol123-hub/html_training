import { Component } from "react";
import { Footer } from "./footer";
import MainHeader from "./header";
import { MainText } from "./main";

class App extends Component{
    render(){
        return <div>
        <MainHeader/>
        <MainText/>
        <Footer/>
        </div> 
    }
}
export default App
import { Component } from "react";
import ChilComp from "./child.component";



class App extends Component{
    
    render(){
        return <div>
         
            <ChilComp></ChilComp>
            
            
        </div>
    }
}
export default App
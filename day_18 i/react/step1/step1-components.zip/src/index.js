import {createRoot} from "react-dom"

createRoot(document.getElementById("root"))
.render(<h1>Anmol Varshney</h1>)